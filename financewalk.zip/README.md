# FinanceWalk

AI-powered financial analysis tool.

## Setup
```
npm install
npm run dev
```